# gitlab-unresolved-threads
Chrome extension to show unresolved threads on gitlab merge request list.

https://chrome.google.com/webstore/detail/gitlab-unresolved-threads/dhmmedpdnmhmdehopnihlpiapdgakkld
