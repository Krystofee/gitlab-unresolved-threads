# gitlab-unresolved-threads
Chrome extension to show unresolved threads on gitlab merge request list.

![preview](https://github.com/Krystofee/gitlab-unresolved-threads/blob/master/preview.png?raw=true)

https://chrome.google.com/webstore/detail/gitlab-unresolved-threads/dhmmedpdnmhmdehopnihlpiapdgakkld
